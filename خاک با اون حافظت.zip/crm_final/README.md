# CRM Bot

یک ربات مدیریت ارتباط با مشتری ساده با FastAPI و Aiogram